import React from "react";

function Info() {
  return (
    <div class="note">
      <h1>Web development with React.js</h1>
      <p>A basic wev dev React bootcamp</p>
    </div>
  );
}
export default Info;
